package com.example.tp2

class PerCapitalGDPFact(value: Float, rank: Rank): QuantitativeFact(value, rank) { override val unit = "$/p" }