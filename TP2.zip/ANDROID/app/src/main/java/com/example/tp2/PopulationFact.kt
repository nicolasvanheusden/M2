package com.example.tp2;

class PopulationFact(value: Float, rank: Rank): QuantitativeFact(value, rank) { override val unit = "" }