package com.example.tp2

class DensityFact(value: Float, rank: Rank): QuantitativeFact(value, rank) { override val unit = "p/km^2" }

