package com.example.tp2

class AreaFact(value: Float, rank: Rank): QuantitativeFact(value, rank) { override val unit = "km^2" }
