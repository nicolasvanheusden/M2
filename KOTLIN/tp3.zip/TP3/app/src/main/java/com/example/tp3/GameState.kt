package com.example.tp3

enum class GameState {
INIT, START, END
}